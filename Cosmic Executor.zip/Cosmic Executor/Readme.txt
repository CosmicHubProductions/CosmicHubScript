thanks for using cosmic blud, to install it js run the pyw file and u finna be good to go
also the keysys.dll file is fake, this executir is keyless!